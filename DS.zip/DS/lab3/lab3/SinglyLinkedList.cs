﻿using System;

public class SinglyLinkedList
{
    Node head;
    String listName;
    public SinglyLinkedList(String name)
    {
        //

    }

    public void popBack()
    {
        if (isEmpty())
        {

        }
        else
        {

        }
    }

    public void popFront()
    {
        if (isEmpty())
        {

        }
        else
        {

        }
    }

    public Node topFront()
    {
        if (isEmpty())
        {
            return new Node();
        }
        else
        {
            return new Node();
        }
    }

    public Node topBack()
    {

        if (isEmpty())
        {
            return new Node();
        }
        else
        {
            return new Node();
        }
    }

    public void pushFront(Node node)
    {
        if (isEmpty())
        {

        }
        else
        {

        }
    }

    public void pushBack(Node node)
    {
        if (isEmpty())
        {

        }
        else
        {

        }
    }

    public Node findNode(int id)
    {
        if (isEmpty())
        {
            return new Node();
        }
        else
        {
            return new Node();
        }
    }

    public Node eraseNode(int id)
    {
        if (isEmpty())
        {
            return new Node();
        }
        else
        {
            return new Node();
        }
    }

    public void addNodeAfter(Node node1, Node node2)
    {

    }

    public void addNodeBefore(Node node1, Node node2)
    {

    }

    public bool isEmpty()
    {
        return false;
    }
    public void merge(SinglyLinkedList list)
    {

    }

    public void printStructure()
    {
        Console.WriteLine("null");
    }

    public Node whoGotHighestGPA()
    {
        if (isEmpty())
        {
            return new Node();
        }
        else
        {
            return new Node();
        }
    }
}