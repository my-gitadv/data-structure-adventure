﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3LinkedList
{
    internal class Node
    {
        public int key;
        public Node next;

        public Node(int key) {
            this.key = key;
        }
    }
}
