﻿namespace exp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Array a = new Array(4);
            a.pushBack(4);
            a.pushBack(5);
            a.pushBack(6);
            a.printAll();

        }
    }
}
