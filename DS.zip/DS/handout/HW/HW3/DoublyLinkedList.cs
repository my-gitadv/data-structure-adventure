﻿using System;

public class DoublyLinkedList
{
    Node head;
    Node tail;
    String listName;
    
    public DoublyLinkedList(String name)
    {
        // Do something
    }

    public void popBack()
    {
        if (isEmpty())
        {
            // Do something
        }
        else
        {
            // Do something
        }
    }

    public void popFront()
    {
        if (isEmpty())
        {
            // Do something
        }
        else
        {
            // Do something
        }
    }

    public Node topFront()
    {
        if (isEmpty())
        {
            // Fix this
            return new Node();
        }
        else
        {
            // Fix this
            return new Node();
        }
    }

    public Node topBack()
    {
        if (isEmpty())
        {
            // Fix this
            return new Node();
        }
        else
        {
            // Fix this
            return new Node();
        }
    }

    public void pushFront(Node node)
    {
        if (isEmpty())
        {
            // Do something
        }
        else
        {
            // Do something
        }
    }

    public void pushBack(Node node)
    {
        if (isEmpty())
        {
            // Do something
        }
        else
        {
            // Do something
        }
    }

    public Node findNode(int id)
    {
        if (isEmpty())
        {
            // Fix this
            return new Node();
        }
        else
        {
            // Fix this
            return new Node();
        }
    }

    public Node eraseNode(int id)
    {
        if (isEmpty())
        {
            // Fix this
            return new Node();
        }
        else
        {
            // Fix this
            return new Node();
        }
    }

    public void addNodeAfter(Node refNode, Node newNode)
    {
        // Do something
    }

    public void addNodeBefore(Node refNode, Node newNode)
    {
        // Do something
    }

    public bool isEmpty()
    {
        // Fix this
        return false;
    }

    public void merge(DoublyLinkedList list)
    {
        // Do something
    }

    public void printStructure()
    {
        // Fix this
        Console.WriteLine("Hello World!");
    }

    // This may be useful for you for implementing printStructure()
    public void printStructureBackward()
    {
        Node current = tail;
        Console.Write(listName + ": tail <-> ");
        while (current != null)
        {
            Console.Write("{" + current.student_id + "} <-> ");
            current = current.previous;
        }

        Console.WriteLine("head");
    }

    public Node whoGotHighestGPA()
    {
        if (isEmpty())
        {
            // Fix this
            return new Node();
        }
        else
        {
            // Fix this
            return new Node();
        }
    }
}