﻿using System;
public class Stack : List
{
    // Implement Stack using Linked List without tail
    Node head;

    public void push(Node node)
    {
        if (head == null)
        {
            // Do something
        }
        else
        {
            // Do something else
        }
    }

    public void pop()
    {
        // Fix the condition
        if (false)
        {
            // Do something
        }
        else
        {
            Console.WriteLine("Error: Stack Underflow");
        }

    }

    public Node top()
    {
        // Fix this
        return new Node(0, 0.0);
    }
}