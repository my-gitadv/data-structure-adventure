﻿public interface List
{
    public void push(Node node);
    public void pop();
    public Node top();
}