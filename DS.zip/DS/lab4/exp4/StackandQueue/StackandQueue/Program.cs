﻿using System;

public class Program
{
    static void Main(string[] args)
    {

        List list = new Stack();
        Console.WriteLine("Top Node = " + list.top());
        list.pop();
        list.push(new Node(30, 130));
        list.push(new Node(40, 140));
        list.push(new Node(50, 150));
        Console.WriteLine("Top Price = " + list.top().price);
        list.pop();
        Console.WriteLine("Top Price = " + list.top().price);
        list.pop();
        Console.WriteLine("Top Price = " + list.top().price);
        list.pop();
        Console.WriteLine("Top Node ID = " + list.top());



        //List list = new Queue();
        //Console.WriteLine("Top Node = " + list.top());
        //list.pop();
        //list.push(new Node(30, 130));
        //list.push(new Node(40, 140));
        //list.push(new Node(50, 150));
        //Console.WriteLine("Top Price = " + list.top().price);
        //list.pop();
        //Console.WriteLine("Top Price = " + list.top().price);
        //list.pop();
        //Console.WriteLine("Top Price = " + list.top().price);
        //list.pop();
        //Console.WriteLine("Top Node ID = " + list.top());



        //Stock ptt = new Stock("FIFO");
        //ptt.showList();
        //ptt.buy(10, 100);
        //ptt.buy(10, 150);
        //ptt.showList();
        //ptt.buy(20, 110);
        //ptt.buy(20, 160);
        //ptt.showList();



        //Stock ptt = new Stock("FIFO");
        //ptt.buy(10, 100);
        //ptt.buy(10, 150);
        //ptt.buy(20, 110);
        //ptt.buy(20, 160);
        //ptt.showList();
        //ptt.sell(25, 130);
        //ptt.showList();



        //Stock ptt = new Stock("LIFO");
        //ptt.buy(10, 100);
        //ptt.buy(10, 150);
        //ptt.buy(20, 110);
        //ptt.buy(20, 160);
        //ptt.showList();
        //ptt.sell(25, 130);
        //ptt.showList();



        //Stock cpall = new Stock("FIFO");
        //cpall.buy(35, 100);
        //cpall.sell(25, 130);
        //cpall.buy(5, 130);
        //cpall.sell(10, 120);
        //cpall.sell(5, 120);

        //cpall = new Stock("LIFO");
        //cpall.buy(35, 100);
        //cpall.sell(25, 130);
        //cpall.buy(5, 130);
        //cpall.sell(10, 120);
        //cpall.sell(5, 120);



        //Stock scb = new Stock("FIFO");
        //scb.buy(5, 100);
        //scb.sell(10, 150);
        //scb.buy(5, 150);
        //scb.sell(10, 150);



        //Stock scb = new Stock("LIFO");
        //scb.buy(5, 100);
        //scb.sell(10, 150);
        //scb.buy(5, 150);
        //scb.sell(0, 125);

    }

}