﻿public class Node
{
    public int shares;
    public double price;
    public Node next;
    public Node(int shares, double price)
    {
        this.shares = shares;
        this.price = price;
    }
}