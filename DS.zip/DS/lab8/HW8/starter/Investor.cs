﻿using System;
public class Investor
{
    int id;
    public String name;
    public double balance;
    public Investor(int id, String name, double budget)
    {
        this.id = id;
        this.name = name;
        this.balance = budget;
    }
}
